import java.sql.*; 
import java.io.*; 
import java.util.*; 
import javax.servlet.*; 
import javax.servlet.http.*; 
public class exam extends HttpServlet 
{ 
String message,Seat_no,Name,ans1,ans2,ans3,ans4,ans5; 
int Total=0;
Connection connect; 
Statement stmt =null; 
ResultSet rs=null; 
public void doPost(HttpServletRequest request,HttpServletResponse response) 
throws ServletException,IOException 
{ 
try 
{ 
String url="jdbc:odbc:StudentDB2"; 
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); 
connect=DriverManager.getConnection(url," "," "); 
message="Connection Successful"; 
} 
catch(ClassNotFoundException cnfex) 
{ 
cnfex.printStackTrace(); 
} 
catch(SQLException sqlex) 
{ 
sqlex.printStackTrace(); 
} 
catch(Exception excp) 
{ 
excp.printStackTrace(); 
} 
Seat_no=request.getParameter("Seat_no"); 
Name=request.getParameter("Name"); 
ans1=request.getParameter("group1"); 
ans2=request.getParameter("group2"); 
ans3=request.getParameter("group3"); 
ans4=request.getParameter("group4"); 
ans5=request.getParameter("group5"); 
if(ans1.equals("True")) 
Total+=2; 
if(ans2.equals("False")) 
Total+=2; 
if(ans3.equals("True")) 
Total+=2; 
if(ans4.equals("True")) 
Total+=2; 
if(ans5.equals("False")) 
Total+=2; 
try 
{ 
Statement stmt=connect.createStatement(); 
String query="INSERT into StudentTable VALUES ("+Seat_no+",'"+Name+"',"+Total+")"; //*****"+"Seat_no,Name,Marks"+")"+" VALUES(" 
int result=stmt.executeUpdate(query);
println("<h1>"+message+"</h1>\n"); 
out.println("<h3>DataBase Updated"); 
out.println("<br><br>"); 
out.println("<b>"+"The Student Database is as follows"); 
out.println("<table border=5>"); 
try 
{ 
Statement stmt=connect.createStatement(); 
String query="SELECT * FROM StudentTable"; 
rs=stmt.executeQuery(query); 
out.println("<th>"+"Seat_no"+"</th>"); 
out.println("<th>"+"Name"+"</th>"); 
out.println("<th>"+"Marks"+"</th>"); 
while(rs.next()) 
{ 
out.println("<tr>"); 
out.println("<td>"+rs.getInt(1)+"</td>"); 
out.println("<td>"+rs.getString(2)+"</td>"); 
out.println("<td>"+rs.getInt(3)+"</td>"); 
out.println("</tr>"); 
} 
out.println("</table>"); 
} 
catch(SQLException ex) 
{} 
finally 
{ 
try 
{ 
if(rs!=null) 
rs.close(); 
if(stmt!=null) 
stmt.close(); 
if(connect!=null) 
connect.close(); 
} 
catch(SQLException e) 
{} 
}
out.println("<center>"); 
out.println("<h1>Thanks!</h1>\n"); 
out.println("</center>"); 
out.println("</body></html>"); 
}} 
